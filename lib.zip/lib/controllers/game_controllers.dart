import '../models/player.dart';
import '../models/sac_lettres.dart';

class GameController {
  final Player player;
  final SacLettres sacLettres = SacLettres();

  GameController(this.player) {
    initialiserPartie();
  }

  void initialiserPartie() {
    player.letters = List.generate(7, (_) => sacLettres.tirerLettre()!.lettre);
  }

  bool jouerLettre(String lettre) {
    if (player.letters.remove(lettre)) {
      //final nouvelleLettre = sacLettres.tirerLettre();
      //if (nouvelleLettre != null) {
        //player.letters.add(nouvelleLettre.lettre);
      //}
      return true;
    }
    return false;
  }

  void addPoints(int points) => player.score += points;

  Player get getPlayer => player;
}
