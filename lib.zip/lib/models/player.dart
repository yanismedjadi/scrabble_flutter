class Player {
  final String name;
  List<String> letters;
  int score;

  Player({
    required this.name,
    this.letters = const [],
    this.score = 0,
  });
}
