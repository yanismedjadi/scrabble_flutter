class Lettre {
  final String lettre;
  final int valeur;
  int quantite;

  Lettre({
    required this.lettre,
    required this.valeur,
    required this.quantite,
  });
}
