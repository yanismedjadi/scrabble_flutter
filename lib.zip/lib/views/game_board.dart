//import 'dart:nativewrappers/_internal/vm/lib/internal_patch.dart';

import 'package:flutter/material.dart';
import '../controllers/game_controllers.dart';
import '../models/player.dart';

class GameBoardScreen extends StatefulWidget {
  @override
  _GameBoardScreenState createState() => _GameBoardScreenState();
}

class _GameBoardScreenState extends State<GameBoardScreen> {
  static const int boardSize = 15;
  late GameController controller;
  List<List<String?>> board = List.generate(boardSize, (_) => List.filled(boardSize, null));

  @override
  void initState() {
    super.initState();
    controller = GameController(Player(name: "Vous"));
  }

  @override
  Widget build(BuildContext context) {
    double gridSize = MediaQuery.of(context).size.width * 0.4;
    double tileSize = gridSize / boardSize;

    return Scaffold(
      appBar: AppBar(title: Text('Scrabble - ${controller.player.name}')),
      body: Column(
        children: [
          // Lettres du joueur
          Container(
            height: 80,
            padding: EdgeInsets.all(8),
            color: Colors.grey[200],
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: controller.player.letters.map((lettre) {
                return Draggable<String>(
                  data: lettre,
                  feedback: Material(
                    child: _lettreTile(lettre, Colors.blue),
                  ),
                  childWhenDragging: Opacity(
                    opacity: 0.5,
                    child: _lettreTile(lettre, Colors.blue),
                  ),
                  child: _lettreTile(lettre, Colors.blue),
                );
              }).toList(),
            ),
          ),
          // Plateau 15x15
          Expanded(
            child : Container(
              width: gridSize,
              height: gridSize,
              child: GridView.builder(
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: boardSize,
                ),
                itemCount: boardSize * boardSize,
                itemBuilder: (context, index) {
                  int row = index ~/ boardSize;
                  int col = index % boardSize;

                  return DragTarget<String>(
                    onAccept: (lettre) {
                      setState(() {
                        board[row][col] = lettre;
                        controller.jouerLettre(lettre);
                        print('$row, $col');
                      });
                    },
                    builder: (context, candidateData, rejectedData) => Container(
                      width: tileSize,
                      height: tileSize,
                      decoration: BoxDecoration(
                        color: board[row][col] != null ? Colors.orange[300] : Colors.white,
                        border: Border.all(color: Colors.grey),
                      ),
                      child: Center(
                        child: Text(
                          board[row][col] ?? '',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _lettreTile(String lettre, Color couleur) {
    return Container(
      width: 40,
      height: 40,
      margin: EdgeInsets.symmetric(horizontal: 3),
      decoration: BoxDecoration(
        color: couleur,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Center(
        child: Text(
          lettre,
          style: TextStyle(fontSize: 20, color: Colors.white),
        ),
      ),
    );
  }
}
